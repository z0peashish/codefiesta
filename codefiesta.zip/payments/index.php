<html>
<head>
</head>
<body>
<form action="l.php" method="post">
Username:<input type="text" name="username"><br>
Passsword<input type="text" name="password"><br>
<button type="submit" name="submit">login</button></form>
</body>
</html> 