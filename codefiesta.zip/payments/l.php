<?php 
session_start();
    $username = "";
	$email    = "";
	$errors = array(); 
	 $_SESSION['success'] = "";
	 

 
	$db = mysqli_connect('localhost', 'codefiesta', 'codefiesta', 'codefiesta');
	 
	 
if (isset($_POST['submit'])) 
	{
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password = mysqli_real_escape_string($db, $_POST['password']);
      $_SESSION['nm']=$username;
		if (empty($username)) 
		{
			  
			 echo "<script>alert('Username is required');</script>";
				echo "<script>window.location.href=' index.php'</script>";
		}
		if (empty($password))
		{
			echo "<script>alert('Password is required');</script>";
				echo "<script>window.location.href=' index.php'</script>";
		}

		if (count($errors) == 0) 
		{
			$password = md5($password);
			$query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
			$results = mysqli_query($db, $query);

			if (mysqli_num_rows($results) == 1) 
			{
				//$_SESSION['username'] = $username;
			//	$_SESSION['success'] = "You are now logged in";
				header('location: hmm.php');
			}
			else {
				echo "<script>alert('Failed');</script>";
				echo "<script>window.location.href=' index.php'</script>";
			}
		}
	}